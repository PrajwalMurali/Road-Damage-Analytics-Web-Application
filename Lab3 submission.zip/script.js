/* ==========================================================================
   Road Damage Reporting & Analytics Portal - Interactive JavaScript
   ========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
  // Page 1: Home Page Interactions
  initHomePage();

  // Page 2: Report Form Validation & Handling
  initReportForm();

  // Page 3: Analytics Search, Filter, Dynamic Table & Counters
  initAnalyticsPage();
});

/* --------------------------------------------------------------------------
   1. HOME PAGE INTERACTIVITY
   -------------------------------------------------------------------------- */
function initHomePage() {
  const toggleEmergencyBtn = document.getElementById("toggle-emergency-btn");
  const emergencyBox = document.getElementById("emergency-details");

  if (toggleEmergencyBtn && emergencyBox) {
    // [Requirement 1 & 7] Handle button click & Show/Hide section
    toggleEmergencyBtn.addEventListener("click", () => {
      const isHidden = emergencyBox.style.display === "none";
      emergencyBox.style.display = isHidden ? "block" : "none";
      toggleEmergencyBtn.textContent = isHidden ? "Hide Emergency Contacts" : "Show Emergency Contacts";
    });
  }
}

/* --------------------------------------------------------------------------
   2. REPORT FORM VALIDATION & DYNAMIC SUBMISSION
   -------------------------------------------------------------------------- */
function initReportForm() {
  const reportForm = document.getElementById("damage-report-form");
  const formFeedback = document.getElementById("form-feedback");

  if (!reportForm) return;

  reportForm.addEventListener("submit", (e) => {
    e.preventDefault();

    // [Requirement 2] Read values entered in input fields
    const name = document.getElementById("reporter-name").value.trim();
    const email = document.getElementById("contact-email").value.trim();
    const phone = document.getElementById("contact-phone").value.trim();
    const damageType = document.getElementById("damage-type").value;
    const severity = document.getElementById("severity").value;
    const location = document.getElementById("location").value.trim();
    const description = document.getElementById("description").value.trim();

    // [Requirement 3] Validate user input using JavaScript
    if (!name || !email || !phone || !damageType || !severity || !location) {
      showFeedback("Please fill out all required fields.", "error");
      return;
    }

    // Phone number validation (10 digits)
    const phoneRegex = /^[6-9]\d{9}$/;
    if (!phoneRegex.test(phone)) {
      showFeedback("Please enter a valid 10-digit Indian mobile number.", "error");
      return;
    }

    // Generate unique Issue ID
    const newId = `#RD-${Math.floor(1000 + Math.random() * 9000)}`;

    // Prepare report data object
    const newReport = {
      id: newId,
      location: location,
      damageType: damageType,
      severity: severity,
      status: "Pending Review",
      description: description
    };

    // Store in localStorage for cross-page persistence
    let existingReports = JSON.parse(localStorage.getItem("portalReports")) || [];
    existingReports.unshift(newReport);
    localStorage.setItem("portalReports", JSON.stringify(existingReports));

    // [Requirement 9] Display alert or confirmation message
    showFeedback(`Success! Your report (${newId}) has been logged successfully.`, "success");

    // [Requirement 4] Dynamically change styles and reset form
    reportForm.reset();
  });

  function showFeedback(message, type) {
    if (!formFeedback) return;
    formFeedback.textContent = message;
    formFeedback.style.display = "block";
    formFeedback.style.padding = "0.75rem";
    formFeedback.style.borderRadius = "4px";
    formFeedback.style.marginBottom = "1rem";

    if (type === "success") {
      formFeedback.style.backgroundColor = "#dcfce7";
      formFeedback.style.color = "#15803d";
      formFeedback.style.border = "1px solid #86efac";
    } else {
      formFeedback.style.backgroundColor = "#fee2e2";
      formFeedback.style.color = "#b91c1c";
      formFeedback.style.border = "1px solid #fca5a5";
    }
  }
}

/* --------------------------------------------------------------------------
   3. ANALYTICS, LIVE SEARCH/FILTER, DYNAMIC TABLE & COUNTERS
   -------------------------------------------------------------------------- */
function initAnalyticsPage() {
  const tableBody = document.getElementById("analytics-table-body");
  const searchInput = document.getElementById("search-input");
  const filterSeverity = document.getElementById("filter-severity");

  if (!tableBody) return;

  // Initial render of storage & default data
  renderAnalyticsTable();

  // [Requirement 1 & 8] Search & Filter event handlers
  if (searchInput) searchInput.addEventListener("input", renderAnalyticsTable);
  if (filterSeverity) filterSeverity.addEventListener("change", renderAnalyticsTable);
}

function renderAnalyticsTable() {
  const tableBody = document.getElementById("analytics-table-body");
  const searchInput = document.getElementById("search-input");
  const filterSeverity = document.getElementById("filter-severity");

  const query = searchInput ? searchInput.value.toLowerCase() : "";
  const selectedSeverity = filterSeverity ? filterSeverity.value.toLowerCase() : "all";

  // Default hardcoded initial data
  const defaultData = [
    { id: "#RD-101", location: "MG Road, Sector 4", type: "Pothole", severity: "high", status: "In Progress" },
    { id: "#RD-102", location: "Indiranagar 10th Main", type: "Surface Cracking", severity: "low", status: "Pending Review" },
    { id: "#RD-103", location: "ORR Service Road", type: "Waterlogging", severity: "medium", status: "Resolved" },
    { id: "#RD-104", location: "Koramangala 8th Block", type: "Road Subsidence", severity: "high", status: "Scheduled" }
  ];

  // Merge default data with user-added reports from localStorage
  const localReports = JSON.parse(localStorage.getItem("portalReports")) || [];
  const formattedLocal = localReports.map(item => ({
    id: item.id,
    location: item.location,
    type: item.damageType.charAt(0).toUpperCase() + item.damageType.slice(1),
    severity: item.severity.toLowerCase(),
    status: item.status
  }));

  const allData = [...formattedLocal, ...defaultData];

  // Clear existing rows
  tableBody.innerHTML = "";

  // [Requirement 8] Filter rows based on search query and severity
  let visibleCount = 0;
  let resolvedCount = 0;
  let inProgressCount = 0;
  let pendingCount = 0;

  allData.forEach((row) => {
    const matchesSearch = row.location.toLowerCase().includes(query) || 
                          row.type.toLowerCase().includes(query) ||
                          row.id.toLowerCase().includes(query);
    const matchesSeverity = selectedSeverity === "all" || row.severity === selectedSeverity;

    if (matchesSearch && matchesSeverity) {
      visibleCount++;

      // Count status metrics for displayed dataset
      if (row.status === "Resolved") resolvedCount++;
      else if (row.status === "In Progress") inProgressCount++;
      else pendingCount++;

      // [Requirement 5] Add HTML elements dynamically (Create table row)
      const tr = document.createElement("tr");

      // Set dynamic severity badge class
      const badgeClass = `badge badge-${row.severity}`;
      const capitalizedSeverity = row.severity.charAt(0).toUpperCase() + row.severity.slice(1);

      tr.innerHTML = `
        <td><strong>${row.id}</strong></td>
        <td>${row.location}</td>
        <td>${row.type}</td>
        <td><span class="${badgeClass}">${capitalizedSeverity}</span></td>
        <td>${row.status}</td>
      `;

      tableBody.appendChild(tr);
    }
  });

  // Handle empty search results
  if (visibleCount === 0) {
    const emptyTr = document.createElement("tr");
    emptyTr.innerHTML = `<td colspan="5" style="text-align:center; padding: 1rem; color: #64748b;">No matching reports found.</td>`;
    tableBody.appendChild(emptyTr);
  }

  // [Requirement 6 & 10] Display calculated results & update counters dynamically
  updateCounters(allData.length, resolvedCount, inProgressCount, pendingCount, visibleCount);
}

function updateCounters(total, resolved, inProgress, pending, visible) {
  const totalElem = document.getElementById("count-total");
  const resolvedElem = document.getElementById("count-resolved");
  const progressElem = document.getElementById("count-progress");
  const pendingElem = document.getElementById("count-pending");
  const rateElem = document.getElementById("resolution-rate");

  if (totalElem) totalElem.textContent = total;
  if (resolvedElem) resolvedElem.textContent = resolved;
  if (progressElem) progressElem.textContent = inProgress;
  if (pendingElem) pendingElem.textContent = pending;

  // [Requirement 6] Calculate resolution percentage
  if (rateElem) {
    const rate = total > 0 ? Math.round((resolved / total) * 100) : 0;
    rateElem.textContent = `${rate}% Resolution Rate (${visible} showing)`;
  }
}