from django.shortcuts import render


def home(request):
    return render(request, "main/index.html")


def analytics(request):
    data = [
        {"name": "Students", "value": 250},
        {"name": "Courses", "value": 12},
        {"name": "Active Users", "value": 180},
        {"name": "Performance", "value": "92%"},
    ]
    return render(request, "main/analytics.html", {"stats": data})


def report(request):
    report_items = [
        "Project submission completed on time.",
        "Attendance shows improvement this month.",
        "Lab tasks are actively being reviewed.",
    ]
    return render(request, "main/report.html", {"report_items": report_items})
