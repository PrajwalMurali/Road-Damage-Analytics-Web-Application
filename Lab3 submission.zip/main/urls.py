from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("analytics/", views.analytics, name="analytics"),
    path("report/", views.report, name="report"),
]
